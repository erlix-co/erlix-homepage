# Packages gmail-web-extension for hosting at erlix.net/bcc-alert/
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$out = Join-Path $root "BCC-Alert-Gmail-Chrome.zip"
if (Test-Path $out) { Remove-Item $out -Force }
Compress-Archive -Path $root -DestinationPath $out -CompressionLevel Optimal
Write-Host "Created $out"
